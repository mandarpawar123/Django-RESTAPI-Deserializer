import requests
import json

URL='http://localhost:8000/stucreate/'

data={
    'name':'mandar',
    'roll':111,
    'city':'maharashtra' 
}  

#converts the python data to json
json_data=json.dumps(data)

#now we can send this data with request
#respone will be stored in r
r=requests.post(url=URL,data=json_data)

#for extract data from r
data_1=r.text
print(data_1)



